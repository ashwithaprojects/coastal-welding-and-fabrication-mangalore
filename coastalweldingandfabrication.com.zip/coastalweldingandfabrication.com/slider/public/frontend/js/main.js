(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
//Application Object
window.app = {

	//Modules
	initComponents: require('./modules/init-components'),
	svg: require('./modules/svg'),
	get: require('./modules/get'),
	loader: require('./modules/loader'),
	parallax: require('./modules/parallax'),
	pageChange: require('./modules/page-change'),

	//Components
	components: {
		header: require('./components/header'),
		hint: require('./components/hint'),
		loader: require('./components/loader'),
		about: require('./components/about'),
		home: require('./components/home'),
		footer: require('./components/footer'),
		contact: require('./components/contact'),
		projects: require('./components/projects'),
		project: require('./components/project'),
	},

	//Templates
	templates: {},

	init: function(){

		app.initComponents();
		app.pageChange();
		app.svg();

	},

};

$(app.init);//Init on Document Ready
},{"./components/about":2,"./components/contact":3,"./components/footer":4,"./components/header":5,"./components/hint":6,"./components/home":7,"./components/loader":8,"./components/project":9,"./components/projects":10,"./modules/get":11,"./modules/init-components":12,"./modules/loader":13,"./modules/page-change":14,"./modules/parallax":15,"./modules/svg":16}],2:[function(require,module,exports){
var $cont 		= $('.about');
var $tabs 		= $cont.find('.abt-tab');
var $menu 		= $cont.find('.abt-menu');
var $wrapper 	= $cont.find('.abt-items');
var $contents 	= $cont.find('.abt-item');

function init(){

	$cont.on('enter', motionIn);
	$cont.on('leave', motionOut);
	$cont.data('motion-out-time', 1600);

	$wrapper.slick({
		fade: true,
		dots: false,
		arrows: false,
		swipe: false,
		adaptiveHeight: true,
	});

	$tabs.on('click', function(){
		var _target = $( this ).data( 'id' );
		motionChangeOut( _target, $(this).index() );
		$tabs.removeClass( 'active' );
		$( this ).addClass( 'active' );
		app.hintIn();
	});

	$( window ).on( 'scroll', onScroll );
	onScroll();

}

function motionChangeOut( _target, _index ){
	$wrapper.find( '.abt-title' ).addClass('change-motion-out');
	$wrapper.find( '.inner' ).addClass('change-motion-out');
	setTimeout( function(){
		$wrapper.find( '.item-img' ).addClass('change-motion-out');
		setTimeout( function(){
			motionChangeIn( _target, _index );
		}, 700 );
	}, 500 );
}

function motionChangeIn( _target, _index ){
	var target = $wrapper.find( '[data-id="'+_target+'"]');
	$wrapper.slick( 'slickGoTo', _index );
	$( target ).find( '.abt-title' ).removeClass( 'change-motion-out' );
	$( target ).find( '.inner' ).removeClass('change-motion-out');
	setTimeout( function()
	{
		$( target ).find( '.item-img' ).removeClass( 'change-motion-out' );
		app.hintOut();
	}, 500 );
}

function onScroll(){
	var scrollTop 	= $(window).scrollTop();

	if( scrollTop >  130 )
	{
		$menu.addClass( 'm-fixed' );
	}
	else
	{
		$menu.removeClass( 'm-fixed' );	
	}

}


// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\
function motionIn(e, oldPage)
{
	app.components.header.motionIn();
	app.components.footer.motionIn();

	$cont.find( '.item-img' ).addClass('motion-in');
	$cont.find( '.abt-menu' ).addClass('motion-in');

	setTimeout( function()
	{
		$cont.find( '.abt-title' ).addClass('motion-in');
		$cont.find( '.inner' ).addClass('motion-in');

		$cont.find( '.abt-tab' ).eq( 0 ).addClass('motion-in');
		
		setTimeout( function()
		{
			$cont.find( '.abt-tab' ).eq( 1 ).addClass('motion-in');	
			app.hintOut();
			app.parallax.on();
		}, 200 );

	}, 200 );
}

function motionOut(e, newPage)
{
	app.hintIn();
	$cont.find( '.abt-title' ).addClass('motion-out');
	$cont.find( '.inner' ).addClass('motion-out');

	setTimeout( function()
	{
		$cont.find( '.item-img' ).removeClass('change-motion-out').addClass('motion-out');
		$cont.find( '.abt-tab' ).eq( 0 ).addClass('motion-out');		
		
		app.components.header.motionOut();
		app.components.footer.motionOut();

		setTimeout( function()
		{
			$cont.find( '.abt-tab' ).eq( 1 ).addClass('motion-out');
			$cont.find( '.abt-menu' ).addClass('motion-out');
		}, 200 );

		
	}, 200 );
}

module.exports = {
	init: init,
	condition: $cont,
	args: arguments,
}
},{}],3:[function(require,module,exports){
var $cont = $('.contact');
var $form = $cont.find('form');

var _msgMorning 	= 'Good Morning, \n';
var _msgAfternoon 	= 'Good Afternoon, \n';
var _msgNight 		= 'Good Evening, \n';
var _msgError 		= 'Ops!<br> An error occurred,<br> please try later';
var _msgSuccess 	= 'Your message has been <br>sent successfully.';


function init(){

	$cont.on('enter', motionIn);
	$cont.on('leave', motionOut);
	$cont.data('motion-out-time', 1600);

	validateForm();

	$form.find('input').setMask();

	$cont.find('input').on('keypress', function(e){
		if (e.which == 13) {
			$form.submit();
			return false;
		}
	});

	if( GLOBAL_LANGUAGE == "pt" ){
		_msgMorning 	= 'Bom Dia, \n';
		_msgAfternoon 	= 'Boa Tarde, \n';
		_msgNight 		= 'Boa Noite, \n';
		_msgError 		= 'Ops!<br> Ocorreu um erro,<br> tente mais tarde.';
		_msgSuccess 	= 'Sua Mensagem foi enviada <br>com sucesso.';
	}

}

function motionIn(e, oldPage){

	app.components.header.motionIn();
	app.components.footer.motionIn();
	app.hintOut();
	app.parallax.on();
	

	setTimeout(function(){

		$cont.find('label').eq(0).addClass('motionIn');
		$cont.find('label').eq(1).addClass('motionIn');
		$cont.find('.mod-textarea').addClass('motionIn');
		$cont.find('label').eq(2).addClass('motionIn');		
		$cont.find('.mod-input').eq(0).addClass('motionIn');
		$cont.find('.mod-input').eq(1).addClass('motionIn');
		$('.signature').addClass('motionIn');

		setTimeout(function(){
			$cont.find('.infos').addClass('motionIn');
			setTimeout(animateType, 1000);
		}, 500);

	}, 1000 + 800);

}

function motionOut(e, newPage){

	app.components.header.motionOut();
	app.components.footer.motionOut();
	app.hintIn();

	$cont.find('.infos').removeClass('motionIn');
	$cont.find('label').eq(2).removeClass('motionIn');		
	$cont.find('.mod-input').eq(0).removeClass('motionIn');
	$cont.find('.mod-input').eq(1).removeClass('motionIn');
	$cont.find('label').eq(1).removeClass('motionIn');
	$cont.find('label').eq(0).removeClass('motionIn');
	$cont.find('.mod-textarea').removeClass('motionIn');
	$('.signature').removeClass('motionIn');
	$cont.find('.message').fadeOut();

}

function whatTimeIsIt(){

	var msg;
	var now = new Date();
	var hours = now.getHours();
	if (hours < 12) msg =_msgMorning;
	else if (hours < 18) msg = _msgAfternoon;
	else msg = _msgNight;
	return msg;

}

function animateType(){
	
	var input = $cont.find('textarea');
    whatTimeIsIt().split('').forEach(function(elem, index){
    	setTimeout(function(){
	        input.val(input.val() + elem);
	    }, index * 100); 
	    input.focus();
	});

}

function validateForm(){

	var _toogle = false;
	
	$form.validate({
		submitHandler: function(form){

			if( !_toogle )
			{
				var datastring = $( form ).serialize();
				$.ajax({
				    type: "POST",
				    url: GLOBAL_URL+'contato/envia_email',
				    data: datastring,
				    dataType: "json",
				    success: function(data) {
				    	$cont.find( '.message' ).find( '.content' ).html( '' );
				    	$cont.find( '.message' ).find( '.content' ).html( _msgSuccess );
			        	$cont.find( '.message' ).fadeIn();
				    },
				    error: function() {
				    	$cont.find( '.message' ).find( '.content' ).html( '' );
				    	$cont.find( '.message' ).find( '.content' ).html( _msgError );
				        $cont.find( '.message' ).fadeIn();
				    }
				});

				_toogle = true;
			}
		},
		ignore: '.ignore',
		errorElement: 'span',
		rules: {
			message: {
				required: true,
			},
			phone: {
				required: true,
			},
			mail: {
				required: true,
				email: true
			},
		},
		messages: {
			message: {
				required: "Por favor digite sua mensagem.",
			},
			phone: {
				required: "Por favor digite seu telefone.",
			},
			mail: {
				required: "Por favor digite um email válido.",
				email: "Por favor digite um email válido."
			},
		},
	});

}

module.exports = {
	init: init,
	condition: $cont,
	args: arguments,
}
},{}],4:[function(require,module,exports){
var $cont = $( '.footer' );

var isMin;

function init(){

}


// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\

function motionIn()
{
	setTimeout( function(){ $cont.find( '.col' ).eq(0).addClass( 'motion-in' ); }, 300 );
	setTimeout( function(){ $cont.find( '.col' ).eq(1).addClass( 'motion-in' ); }, 100 );
	setTimeout( function(){ $cont.find( '.col' ).eq(2).addClass( 'motion-in' ); }, 300 );
}

function motionOut()
{
	setTimeout( function(){ $cont.find( '.col' ).eq(0).removeClass( 'motion-in' ); }, 100 );
	setTimeout( function(){ $cont.find( '.col' ).eq(1).removeClass( 'motion-in' ); }, 300 );
	setTimeout( function(){ $cont.find( '.col' ).eq(2).removeClass( 'motion-in' ); }, 100 );
}

module.exports = {
	init: init,
	motionIn: motionIn,
	motionOut: motionOut,
	condition: $cont,
}
},{}],5:[function(require,module,exports){
var $cont = $('.header');
var $fixed = $cont.clone(true, true).insertAfter($cont).addClass('minified hide');
var $cont = $cont.add($fixed);
var $back = $cont.find( '.bt-back' );

var prevScrollTop = 0;
var breakPoint = 500;
var isHide = true;

function init(){

	$(window).on('scroll', onScroll);
	onScroll();

	$back.on( 'click', goBack );
}

function onScroll(){

	var dHeight = $(document).height();
	var wHeight	= $(window).height();
	var scrollTop = $(window).scrollTop();
	var isScrollingUp = prevScrollTop - scrollTop > 0 ? true : false;

	//Scroll em cima
	if (scrollTop < breakPoint) {
		if (!isHide) {
			$fixed.addClass('hide');
			isHide = true;
		}
	}

	//Scroll no bottom da página
	else if (scrollTop + wHeight >= dHeight) {
		if (isHide) {
			$fixed.removeClass('hide');
			isHide = false;
		}
	}

	//Scroll no meio
	else {
		 if (isScrollingUp) {
		 	if (isHide) {
			 	$fixed.removeClass('hide');
			 	isHide = false;
		 	}
		 } else {
		 	if (!isHide) {
				$fixed.addClass('hide');
				isHide = true;
		 	}
		 }
	}
	
	prevScrollTop = scrollTop;

}

function goBack(){
	window.history.back();
}

// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\

function motionIn()
{
	$cont.find( '.logo' ).addClass( 'motion-in' );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(0).addClass( 'motion-in' ); }, 1200 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(1).addClass( 'motion-in' ); }, 1000 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(2).addClass( 'motion-in' ); }, 1000 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(3).addClass( 'motion-in' ); }, 1200 );
	setTimeout( function(){ $cont.find( '.bt-back' ).addClass( 'motion-in' ); }, 1200 );
}

function motionOut()
{

	if( $cont.hasClass( 'minified' ) )
	{
		$cont.addClass( 'hide' )
	}

	setTimeout( function(){ $cont.find( '.bt-back' ).removeClass( 'motion-in' ); }, 0 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(0).removeClass( 'motion-in' ); }, 0 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(1).removeClass( 'motion-in' ); }, 200 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(2).removeClass( 'motion-in' ); }, 200 );
	setTimeout( function(){ $cont.find( '.head-item' ).eq(3).removeClass( 'motion-in' ); }, 0 );
	setTimeout( function(){ $cont.find( '.logo' ).removeClass( 'motion-in' ); }, 300 );
}

module.exports = {
	init: init,
	motionIn: motionIn,
	motionOut: motionOut,
	condition: $cont,
}
},{}],6:[function(require,module,exports){
var $cont = $('.hint');

function init(){

	app.hintIn = show;
	app.hintOut = hide;

}

function show(){

	$cont.show();
	
}

function hide(){

	$cont.hide();

}

module.exports = {
	init: init,
	condition: $cont,
}
},{}],7:[function(require,module,exports){
var $cont 			= $('.home');
var $wrapper 		= $cont.find('.wrapper');
var $items 			= $cont.find('.item');
var $info 			= $cont.find('.info');
var $header		 	= $('.header');
var $footer 		= $('.footer');

var _setInverval	= null;
var _cont 			= 1;
var _time 			= 12000;
var _color 			= '';
var _length			= 0;

var _title			= '';
var _link			= '';

var _timersOut		= [];

function init(){

	$cont.on('enter', motionIn);
	$cont.on('leave', motionOut);
	$cont.data('motion-out-time', 1600);
	$cont.data('motion-out-fade', 150);

	$cont.find( '.bt-prev' ).on( 'click', function(){
		slideNavigate( 'slickPrev' );
	} );

	$cont.find( '.bt-next' ).on( 'click', function(){
		slideNavigate( 'slickNext' );
	} );
}

function initSlick(){
	$wrapper.slick({
		dots: false,
		arrows: false,
		infinite: true,
		speed: 1000,
		cssEase: 'cubic-bezier(.55,.085,0,.99)',
	});

	$wrapper.on('beforeChange', function(e, slick, current, next){
		var $next 	= slick.$slides.eq(next);

		_color 		= $next.data('color');
		_title 		= $next.data('title');
		_link 		= $next.data('link');
		_cont 		= next;
		_length 	= slick.slideCount;

		setInfos();
	} );

	$wrapper.slick('slickGoTo', 0);
}

function initInterval(){
	_setInverval = setInterval( function(){	
		$wrapper.slick('slickNext');
		slideMotionIn();
		slideMotionOut();
		app.hintIn();
	}, _time );
}

function clearIntervalSlick(){
	clearInterval( _setInverval );
}

function clearSetTimeout(){
	for (var i = 0; i < _timersOut.length; i++){
	    clearTimeout(_timersOut[i]);
	}
}

function slideNavigate( _event ){
	infoMotionOut();
	imageMotionOut();
	clearIntervalSlick();

	_timersOut.push( setTimeout( function(){
		$wrapper.slick( _event );
		clearSetTimeout();
		slideMotionIn();

		setTimeout( function()
		{
			initInterval();	
			slideMotionOut();
		}, 500 );		

	}, 1000 ));

	app.hintIn();
}

function slideMotionIn(){
	_timersOut.push( setTimeout( function(){
		$info.find( '.item-num' ).addClass( 'motion-in' );
		_timersOut.push( setTimeout( function(){
			$info.find( '.item-title' ).addClass( 'motion-in' );
			_timersOut.push( setTimeout( function(){
				$info.find( '.bt-prev' ).addClass( 'motion-in' );
				$info.find( '.item-call' ).addClass( 'motion-in' );
				_timersOut.push( setTimeout( function(){
					$info.find( '.bt-next' ).addClass( 'motion-in' );
					$info.find( '.item-count ' ).addClass( 'motion-in' );
					app.hintOut();
				}, 200 ));
			}, 600 ));
		}, 200 ));
	}, 200 ));

	_timersOut.push( setTimeout( function(){
		_timersOut.push( setTimeout( function(){
			$header.attr('data-color', _color);
			$info.attr('data-color', _color);
			$footer.attr('data-color', _color);
		}, 200 ));
		$wrapper.find( '.item-img' ).addClass( 'motion-change-in' );
	}, 500 ));
}

function slideMotionOut(){
	_timersOut.push( setTimeout( function()
	{
		infoMotionOut();
	}, _time - 1500 ));

	_timersOut.push( setTimeout( function()
	{
		imageMotionOut();
	}, _time - 1500 ));
}

function infoMotionOut(){
	$info.find( '.item-num' ).removeClass( 'motion-in' );
	$info.find( '.item-title' ).removeClass( 'motion-in' );
	$info.find( '.bt-prev' ).removeClass( 'motion-in' );
	$info.find( '.item-call' ).removeClass( 'motion-in' );
	$info.find( '.bt-next' ).removeClass( 'motion-in' );
	$info.find( '.item-count ' ).removeClass( 'motion-in' );
}

function imageMotionOut(){
	$header.attr('data-color', 'black');
	$info.attr('data-color', 'black');
	$footer.attr('data-color', 'black');

	$wrapper.find( '.item-img' ).removeClass( 'motion-change-in' );
}

function setInfos(){
	var _name = _title.split( '<br>' );

	$info.find( '.item-num' ).find( 'span' ).html( '0'+( _cont + 1 )+'.' );
	$info.find( '.item-title' ).find( '.line span' ).eq( 0 ).html( _name[0] );
	$info.find( '.item-title' ).find( '.line span' ).eq( 1 ).html( _name[1] );
	$info.find( '.item-link' ).attr( 'href', _link );
	$info.find( '.item-call' ).attr( 'href', _link );
		
	updateQty();
}

function updateQty(){
	$info.find( '.item-count' ).html( ( _cont + 1 )+'/'+_length );
}



// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\
function motionIn(e, oldPage){
	initSlick();
	$cont.find( '.mask' ).addClass( 'motion-in' );

	setTimeout( function()
	{
		app.hintOut();
		app.components.header.motionIn();
		app.components.footer.motionIn();

		setTimeout( function()
		{
			initInterval();
			slideMotionIn();
			slideMotionOut();
			app.parallax.on();

		},500 );

	},500 );

}

function motionOut(e, newPage){
	app.components.header.motionOut();
	app.components.footer.motionOut();
	app.parallax.off();
	clearIntervalSlick();
	clearSetTimeout();
	infoMotionOut();
	app.hintIn();

	if( newPage == 'project' )
	{
		setTimeout( function()
		{
			$cont.find( '.item-img' ).addClass( 'motion-project' );	
			$cont.addClass('scroll');
		}, 500 );
	}
	else
	{
		$cont.find( '.mask' ).removeClass( 'motion-in' );
		imageMotionOut();
	}

}

module.exports = {
	init: init,
	condition: $cont,
	args: arguments,
}
},{}],8:[function(require,module,exports){
var $cont = $('.loader');
var $progress = $cont.find('.load-progress');

var interval;
var mouseX = 0;
var mouseY = 0;

function init(){

	app.loaderIn = show;
	app.loaderOut = hide;
	app.loaderVal = update;

	$( document ).mousemove( function( e ) {
	    mouseX = e.pageX;
	    mouseY = e.pageY;
	});
}

function update(pcent){

	$progress.html(parseInt(pcent) + '%');

}

function show(){
	
	$progress.html('0%');
	$cont.fadeIn(300);
	$progress.hide();
	$progress.css({left: mouseX, top: mouseY});
	setTimeout(function(){
		$progress.show();
	}, 25);

	interval = setInterval(function(){
		$progress.css({left: mouseX, top: mouseY});
	}, 100);
	
}

function hide(){

	$cont.fadeOut(300);
	$progress.html('0%');
	clearInterval(interval);

}

module.exports = {
	init: init,
	condition: $cont,
}
},{}],9:[function(require,module,exports){
var $cont 		= $('.project');
var $webdoor 	= $('.proj-webdoor');
var $photos 		= $cont.find( '.photos' );
var $inner 		= $cont.find( '.inner' );
var $scrollDown = $('.bt-scrolldown');
var $scrollUp 	= $('.bt-scrollup');
var $btBack 	= $('.bt-back');
var $title 		= $( '.proj-title' );
var _title 		= $( '.proj-title' ).data( 'title' );

var interval;
var mouseX = 0;
var mouseY = 0;

function init(){

	$cont.on('enter', motionIn);
	$cont.on('leave', motionOut);
	$cont.data('motion-out-time', 1600);

	$scrollDown.on( 'click', setScrollDown );
	$scrollUp.on( 'click', setScrollUp );

	$(window).on('scroll', onScroll);
	onScroll();

	setInfos();

	$( document ).mousemove( function( e ) {
	    mouseX = e.clientX;
	    mouseY = e.clientY;
	});
}



function onScroll(){
	var scrollTop = $( window ).scrollTop();

	if( scrollTop < 130 ){
		$scrollDown.find( '.text' ).addClass( 'motion-in' );
		$scrollDown.find( '.svg' ).addClass( 'motion-in' );
	}
	else
	{
		$scrollDown.find( '.text' ).removeClass( 'motion-in' );	
		$scrollDown.find( '.svg' ).removeClass( 'motion-in' );
	}

	if( scrollTop > 800 ){
		$cont.find( '.content-scroll' ).css( { 'display':'none' } );
	}
	else
	{
		$cont.find( '.content-scroll' ).css( { 'display':'block' } );
	}
}

function setScrollDown(){
	$('html,body').animate( { scrollTop: $cont.find( '.proj-webdoor' ).height()+130 }, 1000, 'easeInOutExpo' );
}

function setScrollUp(){
	$('html,body').animate( { scrollTop: 0 }, 1000, 'easeInOutExpo' );
}

function setInfos(){
	$title.find( '.line span' ).eq( 0 ).html( _title );
}


// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\

function motionIn(e, oldPage){

	app.components.header.motionIn();
	app.components.footer.motionIn();
	app.hintOut();

	$cont.find( '.proj-title' ).addClass( 'motion-in' );

	$webdoor.addClass( 'motion-in' );

	setTimeout( function() { $cont.find( '.proj-year' ).addClass( 'motion-in' ); }, 200 );
	setTimeout( function() { $cont.find( '.proj-details' ).addClass( 'motion-in' ); }, 800 );
	setTimeout( function() { $cont.find( '.photo' ).addClass( 'motion-in' ); }, 800 );

	setTimeout( function() { $cont.find( '.bt-scrollup' ).addClass( 'motion-in' ); }, 900 );
	setTimeout( function() { $cont.find( '.proj-next-title' ).addClass( 'motion-in' ); }, 1000 );
	setTimeout( function() { $cont.find( '.proj-next-name' ).addClass( 'motion-in' ); }, 1200 );

	setTimeout( function() { $cont.find( '.bt-scrolldown .svg' ).addClass( 'motion-in' ); }, 1200 );
	setTimeout( function() { $cont.find( '.bt-scrolldown .text' ).addClass( 'motion-in' ); }, 1200 );

}


function motionOut(e, newPage){

	app.hintIn();
	// $cont.find( '.proj-title' ).addClass( 'motion-out' );
	// $cont.find( '.proj-year' ).addClass( 'motion-out' );
	$cont.find( '.bt-scrolldown .svg' ).removeClass( 'motion-in' );
	$cont.find( '.bt-scrolldown .text' ).removeClass( 'motion-in' );

	$cont.find( '.proj-details' ).removeClass( 'motion-in' );
	$cont.find( '.photo' ).removeClass( 'motion-in' );

	// $cont.find( '.bt-scrollup' ).addClass( 'motion-out' );
	// $cont.find( '.proj-next-title' ).addClass( 'motion-out' );
	// $cont.find( '.proj-next-name' ).addClass( 'motion-out' );

	setTimeout( function()
	{
		$webdoor.addClass( 'motion-out' );
		
		app.components.header.motionOut();
		app.components.footer.motionOut();
		
	}, 200 );
}

module.exports = {
	init: init,
	condition: $cont,
	args: arguments,
}
},{}],10:[function(require,module,exports){
var $cont 			= $('.projects:not(.leaving)');
var $slider 		= $cont.find('.slider');
var $items 			= $cont.find('.item');
var $itemsImg		= $cont.find('.item-img');
var $info 			= $cont.find('.info');
var $btPrev 		= $cont.find('.bt-prev');
var $btNext 		= $cont.find('.bt-next');
var $btsFilters 	= $cont.find('.prjs-filter');

var _cont 			= 1;
var _time 			= 8000;

var _num 			= '';
var _title			= '';
var _color			= '';
var _year			= '';
var _link			= '';
var _length 		= 0;

var timers			= [];

var byArrows;
var hadFirst;
var isBusy;

function init(){

	$cont.on('enter', motionIn);
	$cont.on('leave', motionOut);
	$cont.data('motion-out-time', 2000);

	$slider.slick({
		dots: false,
		infinite: false,
		centerMode: true,
		slidesToShow: 1,
		cssEase: 'cubic-bezier(.55,.085,0,.99)',
		centerPadding: '15%',
		arrows: false,
		speed: 1000,
	});

	$slider.on('beforeChange', function(e, slick, current, next){

		isBusy = true;

		var $next 	= slick.$slides.eq(next);

		_color 		= $next.data('color');
		_title 		= $next.data('title');
		_year 		= $next.data('year');
		_link 		= $next.data('link');
		_num 		= ( next + 1 );
		_cont 		= next;
		_length 	= slick.slideCount;

		// console.log( current );
		// console.log( next );

		if (_cont == (_length - 1))$cont.find( '.bt-next' ).addClass( 'desactive' );
		else $cont.find( '.bt-next' ).removeClass( 'desactive' );	

		if (_cont == 0) $cont.find( '.bt-prev' ).addClass( 'desactive' );
		else $cont.find( '.bt-prev' ).removeClass( 'desactive' );

		if (!hadFirst) {
			hadFirst = true;
			setInfos();
		}

		//Se não tiver troca real de slide
		if ($next.is('.slick-current')) return slideMotionIn();

		if (!byArrows) {
			slideNavigate(null, true);
		} else {
			setInfos();
		}

	});

	$slider.on('afterChange', function(e, slick, current, next){
		byArrows = false;
		isBusy = false;
	});

	$cont.find( '.bt-prev' ).on('click', function(){
		byArrows = true;
		if (_cont > 0) slideNavigate('slickPrev');
	});

	$cont.find( '.bt-next' ).on('click', function(){
		byArrows = true;
		if (_cont < (_length - 1)) slideNavigate('slickNext');
	});

	$slider.slick('slickGoTo', 0);

	$btsFilters.on('click', filterClick);

	$slider.on('mousedown', function(){
		slideMotionOut();
	});

	$slider.on('mouseup', function(){
		timers.push(setTimeout(function(){
			if (!isBusy) slideMotionIn();
		}, 250));
	});

}

function filterClick(){

	app.hintIn();

	var cat 	= $(this).data('category');
	var $toshow = $items.filter(cat == 'all' ? '*' : '[data-category="'+cat+'"]');
	var $tohide = $items.not($toshow);

	$btsFilters.removeClass('active').filter(this).addClass('active');
	
	// MOTION OUT
	slideMotionOut();
	$itemsImg.removeClass('motion-in');

	//Após finalizar todos os motion-out
	timers.push(setTimeout(function(){

		$slider.slick('slickFilter', $toshow);
		$slider.slick('slickGoTo', 0, true);

		slideMotionIn();
		setInfos();
		_num = '01.';
		
		$itemsImg	= $cont.find('.item-img');


		$itemsImg.each(function(index){
			var _this = $( this );
			var _delay = 2;

			if( index < 2 )
			{ 
				_delay =  index;
			}

			timers.push(setTimeout(function(){
				_title 		= $slider.find( '.item' ).eq(0).data('title');

				setTimeout(function(){
					app.hintOut();	
				}, 500 );
				
				$( _this ).addClass('motion-in');
				
			}, 200 * _delay ) );
		});

	}, 1500));

}

function clearTimers(){
	for (var i = 0; i < timers.length; i++) clearTimeout(timers[i]);
	timers = [];
}

function slideNavigate(_event, justIn){
	
	if (justIn) {
		slideIn();
	} else {
		
		app.hintIn();
		slideMotionOut();

		timers.push(setTimeout(function(){
			if (_event) $slider.slick(_event);
			timers.push(setTimeout(slideIn, 500));
		}, 1000));

	}

	function slideIn(){
		app.hintOut();
		setInfos();
		slideMotionIn();
	}

}

function slideMotionIn(){

	clearTimers();
	timers.push(setTimeout(function(){
		$info.find('.item-num').addClass('motion-in');
		timers.push(setTimeout(function(){
			$info.find('.item-title').addClass('motion-in');
			timers.push(setTimeout(function(){
				$info.find('.item-year').addClass('motion-in');
				$cont.find('.bt-prev').addClass('motion-in');
				timers.push(setTimeout(function(){
					$cont.find('.bt-next').addClass('motion-in');
				}, 200));
			}, 800));
		}, 200));
	}, 200));

}

function slideMotionOut(){

	clearTimers();
	$info.find( '.item-num' ).removeClass( 'motion-in' );
	$info.find( '.item-title' ).removeClass( 'motion-in' );
	$info.find( '.item-year' ).removeClass( 'motion-in' );

}

function setInfos(){

	$info.find( '.item-num' ).find( 'span' ).html((_cont > 8 ? _num : '0'+_num) + '.' );
	$info.find( '.item-title' ).find( '.line span' ).eq( 0 ).html( _title );
	$info.find( '.item-year' ).find( 'span' ).html( _year );
	$info.find( '.item-link' ).attr( 'href', _link );

}


// ------------------------- \\\
// ---- MOTION IN / OU ----- \\\
// ------------------------- \\\
function motionIn(e, oldPage){
	app.components.header.motionIn();
	app.components.footer.motionIn();
	app.hintOut();

	slideMotionIn();

	$itemsImg.each( function( index ){
		var _this = $( this );
		var _delay = 2;
		if( index < 2 )
		{ 
			_delay =  index;
		}

		timers.push(setTimeout( function() { 
			$( _this ).addClass( 'motion-in' ); 
		}, 200 * _delay ));
	});

	timers.push(setTimeout( function() { $cont.find( '.prjs-filters' ).addClass( 'motion-in' ); }, 400 ));

	$cont.find( '.prjs-arrows' ).addClass( 'motion-in' );

}

function motionOut(e, newPage){
	app.components.header.motionOut();
	app.components.footer.motionOut();
	app.hintIn();

	slideMotionOut()
	timers.push(setTimeout( function() { $cont.find( '.prjs-filters' ).removeClass( 'motion-in' ); }, 400 ));

	$cont.find( '.prjs-arrows' ).removeClass( 'motion-in' );

	$itemsImg.each( function( index ){
		var _this = $( this );
		var _delay = 2;

		if( index < 2 )
		{ 
			_delay =  index;
		}
			
		timers.push(setTimeout( function() { $( _this ).removeClass( 'motion-in' ); }, 200 * _delay ));
	});
}



module.exports = {
	init: init,
	condition: $cont,
	args: arguments,
}
},{}],11:[function(require,module,exports){
module.exports = function(paramKey){

	var pairs = location.search.replace(/^\?/, '').split('&');
	var params = [];

	pairs.forEach(function(item){
		var split = item.split('=');
		var key = split[0];
		var val = split[1];
		params[key] = val;
	});

	var selected = params[paramKey];
	if (selected) selected = decodeURIComponent(selected.replace(/\+/gi, ' '));

	return selected;

}
},{}],12:[function(require,module,exports){
module.exports = function(elem){

	var $elem = $(elem || 'body');
	
	Object.keys(app.components).forEach(function(key){

		var comp = app.components[key];

		if (elem) {
			if (comp.condition) {
				var selector = comp.condition.selector;
				if ($elem.is(selector) || $elem.find(selector).length) {
					var args = Array.prototype.slice.call(comp.args);
					comp.args.callee.apply(this, args);
					app.components[key] = args[1].exports;
					app.components[key].init();
				}
			} else if (comp.each) {
				var selector = comp.each.selector;
				$elem.find(selector).each(comp.init);
				$elem.filter(selector).each(comp.init);
			}
		}

		else {
			if (comp.condition) {
				if (comp.condition.length) comp.init();
			} else if (comp.each) {
				comp.each.each(comp.init);
			}
		}

	});

}
},{}],13:[function(require,module,exports){
module.exports = function(opts){

	var before = opts.before || function(){};
	var progress = opts.progress || function(){};
	var complete = opts.complete || function(){};
	var testDelay = opts.testDelay || 0;
	var $elem = $(opts.elem || 'body');

	var urls = [];
	var queue = [];
	var isLoaded;

	$elem.find('*').add($elem).each(function(){
		var $elem = $(this);
		var bgImg = $elem.css('background-image');
		var bgUrl = (/(^url\([\'\"]?)([^\"\']*)([\'\"]?\))/.exec(bgImg) || [])[2];
		var url;
		if ($elem.is('img')) url = $elem.attr('src');
		else if (bgUrl) url = bgUrl;
		if (url && urls.indexOf(url) < 0) {
			urls.push(url);
			queue.push({src: url, progress: 0});
		}
	});

	if (!urls.length) return complete(urls);

	before();

	function checkProgress(){

		var loaded = 0;
		var total = queue.length;

		queue.forEach(function(item){
			loaded = loaded + item.progress;
		});

		var pcent = loaded * 100 / total;
		progress(pcent);

		if (pcent >= 100 && !isLoaded) {
			isLoaded = true;
			complete(urls);
		}

	}

	queue.forEach(function(item, i){
		setTimeout(function(){

			var req = new XMLHttpRequest();

			req.onprogress = function(e){
				item.progress = e.loaded / e.total;
				checkProgress();
			};

			req.onloadend = req.ontimeout = req.onerror = req.onabort = function(e){
				item.progress = 1;
				checkProgress();
			};

			req.open('GET', item.src, true);
			req.send(null);

		}, testDelay * (i + 1));
	});

}
},{}],14:[function(require,module,exports){
var $title = $('title');
var $header = $('.header');
var $footer = $('.footer');
var $cont = $('.main-content');
var $html = $('html');
var $main = $('main');
var $temp = $('<div></div>');

var loadDelay = 0;
var oldPage;
var promise;
var timer;

function init(){

	//Comaçar com o scroll no topo
	for (var i = 0; i < 800; i = i + 50) setTimeout(function(){
		$(window).scrollTop(0);
	}, i);

	var $loader = $('.loader-init');
	var $loaderText = $loader.find('.loader-text');

	app.loader({
		elem: $('body'),
		// testDelay: loadDelay,
		progress: function(pcent){
			$loader.find('.logo').css('width', (pcent - 100) * -1);
		},
		complete: function(){

			$loader.addClass('motionOut');

			setTimeout(function(){
				$loader.addClass( 'motionOut2' );

				setTimeout(function(){
					$loader.fadeOut( 400 );
					$header.addClass('motionIn');
					$cont.find('> *').trigger('enter').addClass('motion-in').attr('data-location', location.href);
					$html.removeClass('noscroll');
					app.parallax.on();
				}, 1300 );

			}, 1300);

		},
	});

	activeMenus($main.data('page'));

	if (app.get('noloader')) {
		$loader.remove();
		$cont.find('> *').trigger('enter').addClass('motion-in');
		$html.removeClass('noscroll');
		$header.addClass('motionIn');
		app.parallax.on();
	}

	// Ao clicar em qualquer anchor do site
	// $(document).on('click', 'a[href]', function(e){
	$(document).on( 'click', 'a[href]:not(.external)', function(e){
		var url = $(this).attr('href');
		if (url.indexOf('mailto:') == 0) return;
		if ($(this)[0].href == location.href) return false;
		e.preventDefault();
		change(url, $(this).data('page'));
		history.pushState(null, null, url);
	});

	//Ao mudar de página pelo botão voltar/avançar do browser
	setTimeout(function(){
		window.addEventListener('popstate', function(e){
			change(location.href);
		});
	}, 1000);

}

function change(url, newPage){

	if (timer) clearTimeout(timer);
	if (promise && promise.abort) promise.abort();

	var $currSec = $cont.find('> *');
	oldPage = $main.attr('data-page');
	
	//Objeto da requisição
	promise = $.ajax({url: url});

	beforeLeave($currSec, oldPage, newPage);
	$currSec.trigger('leave', [newPage]).addClass('motion-out');

	setTimeout(function(){

		app.loaderIn();

		timer = setTimeout(function(){
			promise.error(function(){
				location.href = url;
			}).success(function(resp){
				handleHTML(resp);
			});
		}, 0);

	}, $currSec.data('motion-out-time') || 800);

}

function handleHTML(html){

	var $all 		= $(html);
	var $pageTitle 	= $all.filter('title');
	var $pageHeader = $all.find($header.selector);
	var $pageFooter = $all.find($footer.selector);
	var $pageCont 	= $all.find($cont.selector);
	var $pageMain 	= $all.filter($main.selector);
	var $newSec 	= $pageCont.find('> *');
	var $oldSec 	= $cont.find('> *').not($newSec);
	var newPage     = $pageMain.attr('data-page');
	var $tempSec 	= $temp.find('> *');
	var isReused;

	// console.log('Handle HTML.', location.href, $tempSec.data('location'), $tempSec.data('persist'));
	if (location.href == $tempSec.data('location') && $tempSec.data('persist')) {
		// console.log('Reusing sec.', $tempSec.data('location'));
		$newSec = $tempSec;
		isReused = true;
	}

	beforeLoadNew($newSec, $oldSec, oldPage, newPage);
	
	app.loader({
		elem: $newSec,
		testDelay: loadDelay,
		progress: function(pcent){
			app.loaderVal(pcent);
		},
		complete: function(){

			app.loaderOut();

			//Atualiza elementos da página
			$title.html($pageTitle.html());
			$footer.attr('class', $pageFooter.attr('class'));
			$header.attr('class', $pageHeader.attr('class'));
			
			// if( newPage != 'project' )
			// {
			$header.removeAttr('data-color');	
			// }
			$footer.removeAttr('data-color');

			$main.attr('data-page', newPage);
			activeMenus(newPage);

			$newSec.hide().appendTo($cont);
			
			$oldSec.addClass('leaving');

			$newSec.show();
			if (!isReused) app.initComponents($newSec);
			app.svg();

			$('html,body').animate({scrollTop: 0}, 1);

			$oldSec.stop().fadeOut($oldSec.data('motion-out-fade') || 0, function(){

				$temp.empty();
				$oldSec.appendTo($temp).removeClass('leaving motion-in motion-out');

				$newSec.trigger('enter', [oldPage]).addClass('motion-in');
				$newSec.attr('data-location', location.href);

				afterEnter($newSec, $oldSec, oldPage, newPage);

			});
			
		},
	});

}

// No momento do clique no link
function beforeLeave($oldSec, oldPage, newPage){

	app.parallax.off();

}

//Após carregar o HTML da próxima página, mas antes mostrar o loader das imagens
function beforeLoadNew($newSec, $oldSec, oldPage, newPage){}

//Após mostrar a próxima página
function afterEnter($newSec, $oldSec, oldPage, newPage){}

function activeMenus(page){
	var $menus = $header.add($footer).find('[data-page]');
	$menus.removeClass('active');
	$menus.filter('[data-page="'+page+'"]').addClass('active');
}

module.exports = init;
},{}],15:[function(require,module,exports){
var $cont = $('.main-content');
var $body = $('body');
var $win = $(window);
var $items = $('');
var isSafari = navigator.userAgent.indexOf('Safari') > -1;
var isOn = true;
var wWidth;
var wHeight;
var mouseX;
var mouseY;
var factorX;
var factorY;

function init(){

	$(window).on('mousemove', mouseMove);
	$(window).on('resize', onResize);
	onResize();

	//Calcula a tela durante o carergamento
	for (var i = 0; i < 5000; i = i + 500) setTimeout(onResize, i);

}

function mouseMove(e){

	if (!isOn) return;

	mouseX = e.pageX;
	mouseY = e.pageY - $win.scrollTop();
	factorX = (mouseX - wWidth / 2) / wWidth * 2;
	factorY = (mouseY - wHeight / 2) / wHeight * 2;

	$items.each(handleItem);

}

function handleItem(){

	var $elem = $(this);
	var scrollTop = $win.scrollTop();
	var offset = $elem.offset();
	var left = offset.left;
	var top = offset.top - scrollTop;
	var width = $items.width();
	var height = $items.height();
	var depth = parseFloat($elem.data('parallax')) * 0.025;
	var centerX = left + width / 2;
	var centerY = top + height / 2;

	var facX = (mouseX - centerX / 2) / wWidth * 2;
	var facY = (mouseY - centerY / 2) / wHeight * 2;

	var offsetX = facX * wWidth * depth;
	var offsetY = facY * wHeight * depth;

	$elem.css({transform: 'translate('+offsetX+'px,'+offsetY+'px)'});

}

function on(){

	onResize();
	$items = $cont.find('[data-parallax]');
	isOn = true;

}

function off(){

	isOn = false;

	$items.css({transform: 'none'});

}

function onResize(){

	wWidth = $body.innerWidth();
	wHeight = $win.innerHeight();

}

init();

module.exports = {
	on: on,
	off: off,
};
},{}],16:[function(require,module,exports){
function init(){

	$('.svg').each(startClass);
	$('[data-svg]').each(startData);

}

function startClass(){

	var $icon = $(this);
	if ($icon.hasClass('svg-inline')) return true;

	var bg = $icon.css('background-image').replace('url(', '').replace(')', '').replace(/\"/g, '');

	if (bg) $.get(bg, function(resp){
		$icon.html($(resp).find('svg')).addClass('svg-inline').trigger('svg-ready');
	});

}

function startData(){

	var $icon = $(this);
	if ($icon.hasClass('svg-inline')) return true;

	var svg = $icon.data('svg');

	if (svg) $.get(svg + '.svg', function(resp){
		$icon.html($(resp).find('svg')).addClass('svg-inline').trigger('svg-ready');
	});

}

module.exports = init;
},{}]},{},[1]);
